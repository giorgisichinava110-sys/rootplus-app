# Root+ (web app)

Open: https://giorgisichinava110-sys.github.io/rootplus-app/

- iPhone: open in Safari → Share → Add to Home Screen
- Windows: open in Edge or Chrome → Install app (icon in the address bar)
